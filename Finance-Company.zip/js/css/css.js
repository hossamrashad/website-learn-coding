$(document).ready(function(){$("body").on("click",".parent-code .copy",function(){$(this).select(),document.execCommand("copy")})});
//# sourceMappingURL=css.js.map
