var x=1,x=2;console.log(x);
//# sourceMappingURL=es6.js.map
